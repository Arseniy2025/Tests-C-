using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace WinFormsApp6
{
    public partial class Form1 : Form
    {
        string connectionString = @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=BD1;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
            InitializeDatabase();
        }

        private void InitializeDatabase()
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\mssqllocaldb;Integrated Security=True"))
            {
                conn.Open();

             
                string createDbQuery = @"
                
                    CREATE DATABASE BD1;
                ";
                using (SqlCommand cmd = new SqlCommand(createDbQuery, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string createCustomersTable = @"
                    CREATE TABLE Customers (
                        Id INT IDENTITY(1,1) PRIMARY KEY,
                        CustomerName NVARCHAR(100),
                        Contact NVARCHAR(100)
                    );
                ";
                using (SqlCommand cmd = new SqlCommand(createCustomersTable, conn))
                {
                    cmd.ExecuteNonQuery();
                }

                
                string createOrdersTable = @"
                CREATE TABLE Orders (
                        Id INT IDENTITY(1,1) PRIMARY KEY,
                        CustomerId INT FOREIGN KEY REFERENCES Customers(Id),
                        OrderAmount DECIMAL(18,2)
                    );
               ";
                using (SqlCommand cmd = new SqlCommand(createOrdersTable, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Customers";
            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(dt);
            }

            dataGridView1.DataSource = dt;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string query = "SELECT Orders.Id, Customers.CustomerName, Orders.OrderAmount FROM Orders JOIN Customers ON Orders.CustomerId = Customers.Id";
            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(dt);
            }

            dataGridView1.DataSource = dt;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string name = txtCustomerName.Text;
            string contact = txtContact.Text;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Customers (CustomerName, Contact) VALUES (@name, @contact)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@contact", contact);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("������ ��������");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int customerId = int.Parse(txtOrderCustomerId.Text);
            decimal amount = decimal.Parse(txtOrderAmount.Text);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Orders (CustomerId, OrderAmount) VALUES (@cid, @amount)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@cid", customerId);
                cmd.Parameters.AddWithValue("@amount", amount);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("����� ��������");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtDeleteCustomerId.Text);
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Customers WHERE Id = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("������ ������");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtDeleteOrderId.Text);
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Orders WHERE Id = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("����� ������");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtUpdateCustomerId.Text);
            string newName = txtNewCustomerName.Text;
            string newContact = txtNewContact.Text;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "UPDATE Customers SET CustomerName = @name, Contact = @contact WHERE Id = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", newName);
                cmd.Parameters.AddWithValue("@contact", newContact);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("������ ��������");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtUpdateOrderId.Text);
            decimal newAmount = decimal.Parse(txtNewOrderAmount.Text);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "UPDATE Orders SET OrderAmount = @amount WHERE Id = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@amount", newAmount);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("����� ��������");
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}