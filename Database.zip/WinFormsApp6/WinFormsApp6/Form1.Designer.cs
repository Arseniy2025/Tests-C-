﻿namespace WinFormsApp6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            groupBox4 = new GroupBox();
            txtDeleteCustomerId = new TextBox();
            label6 = new Label();
            button4 = new Button();
            groupBox3 = new GroupBox();
            txtContact = new TextBox();
            txtCustomerName = new TextBox();
            label1 = new Label();
            button3 = new Button();
            label5 = new Label();
            groupBox2 = new GroupBox();
            txtNewContact = new TextBox();
            txtNewCustomerName = new TextBox();
            txtUpdateCustomerId = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            button2 = new Button();
            groupBox1 = new GroupBox();
            button1 = new Button();
            tabPage2 = new TabPage();
            groupBox8 = new GroupBox();
            txtDeleteOrderId = new TextBox();
            label11 = new Label();
            button8 = new Button();
            groupBox7 = new GroupBox();
            txtOrderAmount = new TextBox();
            txtOrderCustomerId = new TextBox();
            label9 = new Label();
            button6 = new Button();
            label10 = new Label();
            groupBox6 = new GroupBox();
            txtNewOrderAmount = new TextBox();
            txtUpdateOrderId = new TextBox();
            label7 = new Label();
            label8 = new Label();
            button7 = new Button();
            groupBox5 = new GroupBox();
            button5 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            tabPage2.SuspendLayout();
            groupBox8.SuspendLayout();
            groupBox7.SuspendLayout();
            groupBox6.SuspendLayout();
            groupBox5.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(15, 15);
            dataGridView1.Margin = new Padding(4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(970, 375);
            dataGridView1.TabIndex = 0;
            // 
            // tabControl1
            // 
            tabControl1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(15, 398);
            tabControl1.Margin = new Padding(4);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(970, 275);
            tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(groupBox4);
            tabPage1.Controls.Add(groupBox3);
            tabPage1.Controls.Add(groupBox2);
            tabPage1.Controls.Add(groupBox1);
            tabPage1.Location = new Point(4, 34);
            tabPage1.Margin = new Padding(4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(4);
            tabPage1.Size = new Size(962, 237);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Customers";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(txtDeleteCustomerId);
            groupBox4.Controls.Add(label6);
            groupBox4.Controls.Add(button4);
            groupBox4.Location = new Point(585, 8);
            groupBox4.Margin = new Padding(4);
            groupBox4.Name = "groupBox4";
            groupBox4.Padding = new Padding(4);
            groupBox4.Size = new Size(188, 75);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "Удаление";
            // 
            // txtDeleteCustomerId
            // 
            txtDeleteCustomerId.Location = new Point(40, 26);
            txtDeleteCustomerId.Margin = new Padding(4);
            txtDeleteCustomerId.Name = "txtDeleteCustomerId";
            txtDeleteCustomerId.Size = new Size(62, 31);
            txtDeleteCustomerId.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(8, 30);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(34, 25);
            label6.TabIndex = 1;
            label6.Text = "ID:";
            // 
            // btnDeleteCustomer
            // 
            button4.Location = new Point(110, 26);
            button4.Margin = new Padding(4);
            button4.Name = "btnDeleteCustomer";
            button4.Size = new Size(70, 34);
            button4.TabIndex = 0;
            button4.Text = "Del";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(txtContact);
            groupBox3.Controls.Add(txtCustomerName);
            groupBox3.Controls.Add(label1);
            groupBox3.Controls.Add(button3);
            groupBox3.Controls.Add(label5);
            groupBox3.Location = new Point(202, 8);
            groupBox3.Margin = new Padding(4);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(4);
            groupBox3.Size = new Size(375, 75);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Добавление";
            // 
            // txtContact
            // 
            txtContact.Location = new Point(242, 26);
            txtContact.Margin = new Padding(4);
            txtContact.Name = "txtContact";
            txtContact.Size = new Size(124, 31);
            txtContact.TabIndex = 4;
            // 
            // txtCustomerName
            // 
            txtCustomerName.Location = new Point(72, 26);
            txtCustomerName.Margin = new Padding(4);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.Size = new Size(124, 31);
            txtCustomerName.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(205, 30);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(43, 25);
            label1.TabIndex = 2;
            label1.Text = "Тел:";
            // 
            // btnInsertCustomer
            // 
            button3.Location = new Point(8, 26);
            button3.Margin = new Padding(4);
            button3 .Name = "btnInsertCustomer";
            button3.Size = new Size(58, 34);
            button3.TabIndex = 1;
            button3.Text = "OK";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(123, 0);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(51, 25);
            label5.TabIndex = 0;
            label5.Text = "Имя:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(txtNewContact);
            groupBox2.Controls.Add(txtNewCustomerName);
            groupBox2.Controls.Add(txtUpdateCustomerId);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(button2);
            groupBox2.Location = new Point(202, 90);
            groupBox2.Margin = new Padding(4);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(4);
            groupBox2.Size = new Size(375, 125);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Обновление";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // txtNewContact
            // 
            txtNewContact.Location = new Point(242, 60);
            txtNewContact.Margin = new Padding(4);
            txtNewContact.Name = "txtNewContact";
            txtNewContact.Size = new Size(124, 31);
            txtNewContact.TabIndex = 6;
            // 
            // txtNewCustomerName
            // 
            txtNewCustomerName.Location = new Point(242, 19);
            txtNewCustomerName.Margin = new Padding(4);
            txtNewCustomerName.Name = "txtNewCustomerName";
            txtNewCustomerName.Size = new Size(124, 31);
            txtNewCustomerName.TabIndex = 5;
            // 
            // txtUpdateCustomerId
            // 
            txtUpdateCustomerId.Location = new Point(50, 22);
            txtUpdateCustomerId.Margin = new Padding(4);
            txtUpdateCustomerId.Name = "txtUpdateCustomerId";
            txtUpdateCustomerId.Size = new Size(62, 31);
            txtUpdateCustomerId.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(142, 64);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(92, 25);
            label4.TabIndex = 3;
            label4.Text = "Контакты:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(142, 22);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(51, 25);
            label3.TabIndex = 2;
            label3.Text = "Имя:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(8, 22);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(34, 25);
            label2.TabIndex = 1;
            label2.Text = "ID:";
            // 
            // btnUpdateCustomer
            // 
            button2.Location = new Point(8, 60);
            button2.Margin = new Padding(4);
            button2.Name = "btnUpdateCustomer";
            button2.Size = new Size(128, 58);
            button2.TabIndex = 0;
            button2.Text = "Обновить";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button1);
            groupBox1.Location = new Point(8, 8);
            groupBox1.Margin = new Padding(4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4);
            groupBox1.Size = new Size(188, 75);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Просмотр";
            // 
            // btnLoadCustomers
            // 
            button1.Location = new Point(8, 32);
            button1.Margin = new Padding(4);
            button1.Name = "btnLoadCustomers";
            button1.Size = new Size(172, 35);
            button1.TabIndex = 0;
            button1.Text = "Загрузить";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(groupBox8);
            tabPage2.Controls.Add(groupBox7);
            tabPage2.Controls.Add(groupBox6);
            tabPage2.Controls.Add(groupBox5);
            tabPage2.Location = new Point(4, 34);
            tabPage2.Margin = new Padding(4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(4);
            tabPage2.Size = new Size(962, 237);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Orders";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            groupBox8.Controls.Add(txtDeleteOrderId);
            groupBox8.Controls.Add(label11);
            groupBox8.Controls.Add(button8);
            groupBox8.Location = new Point(585, 8);
            groupBox8.Margin = new Padding(4);
            groupBox8.Name = "groupBox8";
            groupBox8.Padding = new Padding(4);
            groupBox8.Size = new Size(188, 75);
            groupBox8.TabIndex = 4;
            groupBox8.TabStop = false;
            groupBox8.Text = "Удаление";
            // 
            // txtDeleteOrderId
            // 
            txtDeleteOrderId.Location = new Point(40, 26);
            txtDeleteOrderId.Margin = new Padding(4);
            txtDeleteOrderId.Name = "txtDeleteOrderId";
            txtDeleteOrderId.Size = new Size(62, 31);
            txtDeleteOrderId.TabIndex = 2;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(8, 30);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(34, 25);
            label11.TabIndex = 1;
            label11.Text = "ID:";
            // 
            // btnDeleteOrder
            // 
            button8.Location = new Point(110, 26);
            button8.Margin = new Padding(4);
            button8.Name = "btnDeleteOrder";
            button8.Size = new Size(70, 34);
            button8.TabIndex = 0;
            button8.Text = "Del";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // groupBox7
            // 
            groupBox7.Controls.Add(txtOrderAmount);
            groupBox7.Controls.Add(txtOrderCustomerId);
            groupBox7.Controls.Add(label9);
            groupBox7.Controls.Add(button6);
            groupBox7.Controls.Add(label10);
            groupBox7.Location = new Point(202, 8);
            groupBox7.Margin = new Padding(4);
            groupBox7.Name = "groupBox7";
            groupBox7.Padding = new Padding(4);
            groupBox7.Size = new Size(375, 75);
            groupBox7.TabIndex = 3;
            groupBox7.TabStop = false;
            groupBox7.Text = "Добавление";
            // 
            // txtOrderAmount
            // 
            txtOrderAmount.Location = new Point(242, 26);
            txtOrderAmount.Margin = new Padding(4);
            txtOrderAmount.Name = "txtOrderAmount";
            txtOrderAmount.Size = new Size(124, 31);
            txtOrderAmount.TabIndex = 4;
            // 
            // txtOrderCustomerId
            // 
            txtOrderCustomerId.Location = new Point(72, 26);
            txtOrderCustomerId.Margin = new Padding(4);
            txtOrderCustomerId.Name = "txtOrderCustomerId";
            txtOrderCustomerId.Size = new Size(124, 31);
            txtOrderCustomerId.TabIndex = 3;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(230, -3);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(103, 25);
            label9.TabIndex = 2;
            label9.Text = "Стоимость:";
            // 
            // btnInsertOrder
            // 
            button6.Location = new Point(8, 26);
            button6.Margin = new Padding(4);
            button6.Name = "btnInsertOrder";
            button6.Size = new Size(58, 34);
            button6.TabIndex = 1;
            button6.Text = "OK";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(107, 0);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(102, 25);
            label10.TabIndex = 0;
            label10.Text = "ID клиента:";
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(txtNewOrderAmount);
            groupBox6.Controls.Add(txtUpdateOrderId);
            groupBox6.Controls.Add(label7);
            groupBox6.Controls.Add(label8);
            groupBox6.Controls.Add(button7);
            groupBox6.Location = new Point(202, 90);
            groupBox6.Margin = new Padding(4);
            groupBox6.Name = "groupBox6";
            groupBox6.Padding = new Padding(4);
            groupBox6.Size = new Size(312, 125);
            groupBox6.TabIndex = 4;
            groupBox6.TabStop = false;
            groupBox6.Text = "Обновление";
            // 
            // txtNewOrderAmount
            // 
            txtNewOrderAmount.Location = new Point(180, 60);
            txtNewOrderAmount.Margin = new Padding(4);
            txtNewOrderAmount.Name = "txtNewOrderAmount";
            txtNewOrderAmount.Size = new Size(124, 31);
            txtNewOrderAmount.TabIndex = 6;
            // 
            // txtUpdateOrderId
            // 
            txtUpdateOrderId.Location = new Point(50, 22);
            txtUpdateOrderId.Margin = new Padding(4);
            txtUpdateOrderId.Name = "txtUpdateOrderId";
            txtUpdateOrderId.Size = new Size(62, 31);
            txtUpdateOrderId.TabIndex = 4;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(180, 31);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(103, 25);
            label7.TabIndex = 2;
            label7.Text = "Стоимость:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(8, 22);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(34, 25);
            label8.TabIndex = 1;
            label8.Text = "ID:";
            // 
            // btnUpdateOrder
            // 
            button7.Location = new Point(8, 60);
            button7.Margin = new Padding(4);
            button7.Name = "btnUpdateOrder";
            button7.Size = new Size(128, 58);
            button7.TabIndex = 0;
            button7.Text = "Обновить";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(button5);
            groupBox5.Location = new Point(8, 8);
            groupBox5.Margin = new Padding(4);
            groupBox5.Name = "groupBox5";
            groupBox5.Padding = new Padding(4);
            groupBox5.Size = new Size(188, 75);
            groupBox5.TabIndex = 1;
            groupBox5.TabStop = false;
            groupBox5.Text = "Просмотр";
            // 
            // btnLoadOrders
            // 
            button5.Location = new Point(8, 32);
            button5.Margin = new Padding(4);
            button5.Name = "btnLoadOrders";
            button5.Size = new Size(172, 35);
            button5.TabIndex = 0;
            button5.Text = "Загрузить";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 688);
            Controls.Add(tabControl1);
            Controls.Add(dataGridView1);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Database ";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            groupBox8.ResumeLayout(false);
            groupBox8.PerformLayout();
            groupBox7.ResumeLayout(false);
            groupBox7.PerformLayout();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            groupBox5.ResumeLayout(false);
            ResumeLayout(false);

        }

        #endregion

        private DataGridView dataGridView1;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private GroupBox groupBox1;
        private Button button1;
        private GroupBox groupBox4;
        private GroupBox groupBox3;
        private GroupBox groupBox2;
        private TextBox txtNewContact;
        private TextBox txtNewCustomerName;
        private TextBox txtUpdateCustomerId;
        private Label label4;
        private Label label3;
        private Label label2;
        private Button button2;
        private TextBox txtContact;
        private TextBox txtCustomerName;
        private Label label1;
        private Button button3;
        private Label label5;
        private TextBox txtDeleteCustomerId;
        private Label label6;
        private Button button4;
        private GroupBox groupBox8;
        private GroupBox groupBox7;
        private GroupBox groupBox6;
        private GroupBox groupBox5;
        private Button button5;
        private TextBox txtOrderAmount;
        private TextBox txtOrderCustomerId;
        private Label label9;
        private Button button6;
        private Label label10;
        private TextBox txtNewOrderAmount;
        private TextBox txtUpdateOrderId;
        private Label label7;
        private Label label8;
        private Button button7;
        private TextBox txtDeleteOrderId;
        private Label label11;
        private Button button8;
    }
}